# .6cy Container Format

This repository contains the reference implementation for the **.6cy container format**, a modern, efficient, and robust solution for data archiving and compression. The format emphasizes streaming, recoverability, per-block codec polymorphism, and a metadata-first index.

## Features

*   **Streaming-friendly**: Designed for efficient processing of data streams.
*   **Recoverable**: Built-in mechanisms for recovery from data corruption or truncation.
*   **Per-block Codec Polymorphism**: Allows different compression algorithms (e.g., Zstandard, LZ4) to be used on a block-by-block basis within a single archive.
*   **Metadata-first Index**: Enables quick listing and access to archive contents without needing to read the entire file.
*   **Rust Reference Implementation**: A high-performance and memory-safe implementation in Rust.
*   **Command-Line Interface (CLI)**: A `6cy` CLI tool for packing, unpacking, listing, and inspecting archives.

## Project Structure

```
.6cy_project/
├── Cargo.toml
├── Cargo.lock
├── src/
│   ├── main.rs         # CLI entry point
│   ├── lib.rs          # Library entry point
│   ├── block.rs        # Data block encoding/decoding
│   ├── codec/          # Codec traits and implementations (Zstd, LZ4)
│   │   └── mod.rs
│   ├── index/          # File index structure and serialization
│   │   └── mod.rs
│   ├── io_stream/      # High-level writer and reader for .6cy files
│   │   └── mod.rs
│   ├── recovery/       # Recovery map and checkpointing
│   │   └── mod.rs
│   └── superblock.rs   # Superblock structure and I/O
├── tests/              # Integration tests
│   └── integration_test.rs
├── benches/            # Performance benchmarks
│   └── compression_bench.rs
├── spec.md             # Detailed binary format specification
└── security_profile.md # Security threat model and hardening guidelines
```

## Getting Started

### Prerequisites

*   [Rust](https://www.rust-lang.org/tools/install) (latest stable version recommended)

### Building the Project

Navigate to the project directory and build using Cargo:

```bash
cd .6cy_project
cargo build --release
```

This will compile the `sixcy` library and the `6cy` CLI tool.

### Running the CLI

After building, the `6cy` executable will be located in `target/release/`.

**Pack a file:**

```bash
target/release/6cy pack -o my_archive.6cy my_file.txt --codec zstd
```

**List archive contents:**

```bash
target/release/6cy list my_archive.6cy
```

**Unpack an archive:**

```bash
target/release/6cy unpack my_archive.6cy -C output_directory/
```

**View archive information:**

```bash
target/release/6cy info my_archive.6cy
```

**Optimize an archive:**

```bash
target/release/6cy optimize my_archive.6cy -o optimized_archive.6cy
```

## Documentation

*   **`spec.md`**: Detailed byte-level specification of the .6cy format.
*   **`security_profile.md`**: Comprehensive document outlining the security considerations, threat model, and hardening measures.

## Contributing

Contributions are welcome! Please refer to `CONTRIBUTING.md` (to be added) and `CODE_OF_CONDUCT.md` (to be added) for guidelines.

## License

This project is licensed under the [MIT License](LICENSE) (to be added).
