# .6cy Container Format Specification

## Phase A - Vision & Scope

### 1. Finalize format goals

The primary goals for the .6cy container format are: **streaming**, **recoverable**, **per-block codec polymorphism**, and a **metadata-first index**.

### 2. Executive spec doc

This document serves as the executive specification for the .6cy container format, outlining its design, purpose, and key features. The .6cy format is designed to be a modern, efficient, and robust container for various data types, emphasizing flexibility in compression and data integrity.

### 3. Minimal set of MUST features (v1) and MAY features (v2+)

**MUST Features (v1):**
* Streaming capability
* Recoverable from corruption/truncation
* Per-block codec polymorphism
* Metadata-first index
* Zstandard (default) and LZ4 codec support

**MAY Features (v2+):**
* Deduplication
* Encryption-ready
* Solid mode
* BFCF optional layer

### 4. Define target platforms and languages

The primary target language for the reference implementation is **Rust**, with bindings planned for other languages (e.g., Python, Go) to ensure broad compatibility and ease of integration. Target platforms include Linux, macOS, and Windows.

### 5. Publish repository skeleton

The repository skeleton will include essential files for open-source projects:
* `LICENSE`
* `CONTRIBUTING.md`
* `CODE_OF_CONDUCT.md`
* `README.md`


## Phase B - Binary Format Spec (byte-level)

This section details the byte-level specification of the .6cy container format.

### 1. Define Superblock (fixed header)

The Superblock is a fixed-size header at the beginning of the .6cy file, containing essential metadata for parsing the archive. It includes:

*   **Magic Number:** A unique identifier to recognize .6cy files.
*   **Version:** Format version to ensure compatibility.
*   **UUID:** A unique identifier for the archive.
*   **Offsets:** Pointers to key sections like the FileIndex and RecoveryMap.
*   **Feature Bitmap:** Flags indicating supported features.

### 2. Define Feature Bitmap values

The Feature Bitmap is a bitmask within the Superblock, where each bit represents a specific feature:

*   Bit 0: Streaming support
*   Bit 1: Recovery enabled
*   Bit 2: Per-block codec polymorphism
*   Bit 3: Deduplication support
*   Bit 4: Encryption-ready

### 3. Define FileIndex record layout

The FileIndex contains records for each file within the archive, enabling efficient lookup and random access. Each record includes:

*   **IDs:** Unique identifier for the file.
*   **parent_id:** Identifier of the parent directory (for hierarchical structures).
*   **offsets:** Starting offset of the file's data blocks.
*   **sizes:** Original and compressed sizes of the file.
*   **TLV metadata:** Type-Length-Value encoded metadata for flexible attributes.

### 4. Define DataBlock layout

DataBlocks store the actual compressed data. Each DataBlock has a header containing:

*   **block magic:** Identifier for a data block.
*   **block_size:** Size of the compressed payload.
*   **file_id:** Identifier of the file this block belongs to.
*   **file_offset:** Offset within the original file.
*   **codec_id:** Identifier of the compression codec used for this block.
*   **level:** Compression level used.
*   **flags:** Block-specific flags.
*   **checksum:** Integrity check for the payload.
*   **payload:** The compressed data.

### 5. Define RecoveryMap structure and periodic checkpointing rules

The RecoveryMap allows for robust recovery from truncated or corrupted archives. It consists of periodic checkpoints that record the state of the archive at specific intervals, enabling readers to resume parsing from the last valid checkpoint.

### 6. Define End Footer and global integrity checks

The End Footer is located at the end of the .6cy file and contains global integrity checks, such as a checksum of the entire archive or a signature, to ensure the overall integrity of the file.

### 7. Specify codec_id enum and stable IDs

To support per-block codec polymorphism, a `codec_id` enum is defined with stable identifiers:

| Codec     | ID |
| :-------- | :- |
| ZSTD      | 1  |
| LZ4       | 2  |
| BROTLI    | 3  |
| LZMA      | 4  |
| ...       | ...|

### 8. Write examples (hex dumps) for an archive with 1 file and for multi-file archive

*(Detailed hex dump examples will be provided in a separate attachment or as part of the Rust implementation's test vectors.)*

**Deliverables:** `spec.md` (byte tables + examples), canonical test vectors.
